package servidor.test;

import servidor.servicio.Servidor;

public class Test {
    public static void main(String[] args) {
        Servidor servidor = new Servidor();
        servidor.servicio();
    }
}
